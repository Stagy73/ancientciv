// Add to server.js
const cardsRoute = require('./routes/cards');
app.use(cardsRoute);
